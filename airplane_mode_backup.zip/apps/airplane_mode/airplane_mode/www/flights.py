import frappe

def get_context(context):
    context.flights = frappe.get_all(
        "Airplane Flight",
        filters={"docstatus": 1},
        fields=[
            "name",
            "airline",
            "source_airport_code",
            "destination_airport_code",
            "departure_time",
            "duration"
        ],
        order_by="departure_time asc"
    )
