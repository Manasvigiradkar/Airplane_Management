# Copyright (c) 2026, Manasvi and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestAirplane(FrappeTestCase):
	pass
